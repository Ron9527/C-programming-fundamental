﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _501assessment2
{
    class Customers
    {
        private string name = null;
        private int accountNum, month;
        private double owingNumBegin, purchasesNum, paymentsNum, owingNumEnd;
        public Customers()
        {

        }
        public string GetName
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public int GetAccountNum
        {
            get
            {
                return accountNum;
            }
            set
            {
                accountNum = value;
            }
        }
        public double GetOwingBegin
        {
            get
            {
                return owingNumBegin;
            }
            set
            {
                owingNumBegin = value;
            }
        }
        public double GetPurchasesNum
        {
            get
            {
                return purchasesNum;
            }
            set
            {
                purchasesNum = value;
            }
        }
        public double GetPayNum
        {
            get
            {
                return paymentsNum;
            }
            set
            {
                paymentsNum = value;
            }
        }
        public int GetMonth
        {
            get
            {
                return month;
            }
            set
            {
                month = value;
            }
        }

        public double GetOwingEnd(double owingBegin, double purchase, double payment)
        {
            owingNumEnd = owingBegin + purchase - payment;
            if (owingNumEnd > 400)
            {
                Console.WriteLine("Credit limit exceeded!!!!!!");
            }
            return owingNumEnd;
        }
        public override string ToString()
        {
            return $"customer's name:\n{name}\nAccount Number:\n{accountNum}\nMonth:\n{month}\nOwing to David Jones at beginning:\n{owingNumBegin:c}\nTotal purchases number:\n{purchasesNum:c}\nTotal payment number:\n{paymentsNum:c}\nOwing to David Jones at end:\n{GetOwingEnd(owingNumBegin, purchasesNum, paymentsNum):c} ";
        }
    }
}
