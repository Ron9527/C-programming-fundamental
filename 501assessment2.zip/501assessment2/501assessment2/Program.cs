﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _501assessment2
{
    class Program
    {
        static int numOfCustomer, numOfSupplier, month;
        static string name, accountNum, owingNumBegin, purchaseNum, paymentNum, check, sMonth;
        static Customers[] customer;
        static Suppliers[] supplier;
        static void Main(string[] args)
        {
            if (Check("customers"))
            {
                GetNum('c');
                GetInfo('c');
            }
            if (Check("suppliers"))
            {
                Console.Clear();
                GetNum('s');
                GetInfo('s');
            }
            else
            {
                Console.Clear();
            }
            Output(numOfCustomer, numOfSupplier, customer, supplier);
            Console.ReadLine();
        }
        static bool Check(string customerOrSupplier)
        {
            Console.WriteLine("Do u want to check " + customerOrSupplier +"'s status, press y or Y for sure");

             check = Console.ReadLine();
            if (check == "y" || check == "Y")
            {
                return true;
            }
            return false;
        }
        static void GetNum(char cOrS)
        {
            string sNum;
            switch (cOrS)
            {
                case 'c':
                    Console.WriteLine("How many customers do u want to check?");
                    sNum = Console.ReadLine();
                    if (int.TryParse(sNum, out numOfCustomer) && int.Parse(sNum) > 0)
                    {
                        numOfCustomer = int.Parse(sNum);
                    }
                    else
                    {
                        Console.WriteLine("Invalid input, plz input number of customers");
                        GetNum(cOrS);
                    }
                    break;
                case 's':
                    Console.WriteLine("How many suppliers do u want to check?");
                    sNum = Console.ReadLine();
                    if (int.TryParse(sNum, out numOfSupplier) && int.Parse(sNum) > 0)
                    {
                        numOfSupplier = int.Parse(sNum);
                    }
                    else
                    {
                        Console.WriteLine("Invalid input, plz input number of suppliers");
                        GetNum(cOrS);
                    }
                    break;
                default:
                    Console.WriteLine("parameter incorrect, c for customer and s for supplier");
                    break;
            }
 
        }
        static void Output(int numOfC, int numOfS, Customers[]A, Suppliers[]B)
        {
            for (int i = 0; i < numOfC; i++)
            {
                Console.WriteLine("NO.{0} {1}", i + 1, A[i].ToString());
                Console.WriteLine();
            }
            for (int i = 0; i < numOfS; i++)
            {
                Console.WriteLine("NO.{0} {1}", i + 1, B[i].ToString());
                Console.WriteLine();
            }
        }
        static void GetInfo(char cOrS)
        {
            switch (cOrS)
            {
                case 'c':
                    customer = new Customers[numOfCustomer];
                    for (int record = 0; record < numOfCustomer; record++)
                    {
                        customer[record] = new Customers();
                        customer[record].GetName = GainName(record, cOrS);
                        customer[record].GetAccountNum = GainAccountNum(record, cOrS);
                        customer[record].GetMonth = GainMonth(record, cOrS);
                        customer[record].GetOwingBegin = OwingNumBegin(record, cOrS);
                        customer[record].GetPurchasesNum = PurchaseNum(record, cOrS);
                        customer[record].GetPayNum = PaymentNum(record, cOrS);
                        Console.Clear();
                    }
                    break;
                case 's':
                    supplier = new Suppliers[numOfSupplier];
                    for (int record = 0; record < numOfSupplier; record++)
                    {
                        supplier[record] = new Suppliers();
                        supplier[record].GetName = GainName(record, cOrS);
                        supplier[record].GetAccountNum = GainAccountNum(record, cOrS);
                        supplier[record].GetMonth = GainMonth(record, cOrS);
                        supplier[record].GetOwingBegin = OwingNumBegin(record, cOrS);
                        supplier[record].GetPurchasesNum = PurchaseNum(record, cOrS);
                        supplier[record].GetPayNum = PaymentNum(record, cOrS);
                        Console.Clear();
                    }
                    break;
                default:
                    break;
            }
        }
        static string GainName(int number, char cOrS)
        {
            switch (cOrS)
            {
                case 'c':
                    Console.WriteLine("input NO.{0} customer's name", number + 1);
                    name = Console.ReadLine();
                    while (6 > name.Length || name.Length > 15)
                    {
                        Console.WriteLine("Invalid name, length should be 6-15, type again");
                        GainName(number, cOrS);
                    }
                    break;
                case 's':
                    Console.WriteLine("input NO.{0} supplier's name", number + 1);
                    name = Console.ReadLine();
                    while (5 > name.Length || name.Length > 16)
                    {
                        Console.WriteLine("Invalid name, length should be 5-16, type again");
                        GainName(number, cOrS);
                    }
                    break;
                default:
                    break;
            }
            
 
            return name;
        }
        static int GainAccountNum(int number, char cOrS)
        {
            int i = 0;
            switch(cOrS)
            {
                case 'c':
                    Console.WriteLine("input NO.{0} customer's account number", number + 1);
                    accountNum = Console.ReadLine();
                    while (!accountNum.StartsWith("1") || accountNum.Length != 6 || !int.TryParse(accountNum, out i))
                    {
                        Console.WriteLine("Invalid account Number,should start with 1 and length is 6 with digital number, type again");
                        GainAccountNum(number, 'c');
                    }
                    break;
                 case's':
                    Console.WriteLine("input NO.{0} supplier's account number", number + 1);
                    accountNum = Console.ReadLine();
                    while (!accountNum.StartsWith("2") || accountNum.Length != 6 || !int.TryParse(accountNum, out i))
                    {
                        Console.WriteLine("Invalid account Number,should start with 2 and length is 6 with digital number, type again");
                        GainAccountNum(number, 's');
                    }
                    break;
                default:
                    Console.WriteLine("parameter incorrect, c for customer and s for supplier");
                    break;
            }
            return int.Parse(accountNum);
        }
        static int GainMonth(int number, char cOrS)
        {
            switch (cOrS)
            {
                case 'c':
                    Console.WriteLine("input which month of NO.{0} customer you will track", number + 1);
                    break;
                case 's':
                    Console.WriteLine("input which month of NO.{0} supplier you will track", number + 1);
                    break;
                default:
                    Console.WriteLine("parameter incorrect, c for customer and s for supplier");
                    break;
            }
            sMonth = Console.ReadLine();
            if (!int.TryParse(sMonth, out month) || 1 > int.Parse(sMonth) || 12 < int.Parse(sMonth))
            {
                Console.WriteLine("Invalid month, should be 1-12, type again");
                GainMonth(number, cOrS);
            }
            //month = int.Parse(sMonth);
            return month;
        }
static double OwingNumBegin(int number, char cOrS)
        {
            double i;
            switch (cOrS)
            {
                case 'c':
                    Console.WriteLine("input NO.{0} customer's owing number", number + 1);
                    break;
                case 's':
                    Console.WriteLine("input NO.{0} supplier's owing number by David Jones", number + 1);
                    break;
                default:
                    Console.WriteLine("parameter incorrect, c for customer and s for supplier");
                    break;
            }
            owingNumBegin = Console.ReadLine();
            while (!double.TryParse(owingNumBegin, out i) || double.Parse(owingNumBegin) < 0.0)
            {
                Console.WriteLine("Invalid owing Number, should be double and greater or equal to 0, type again");
                OwingNumBegin(number, cOrS);
            }
            return double.Parse(owingNumBegin);
        }
        static double PurchaseNum(int number, char cOrS)
        {
            double i;
            switch (cOrS)
            {
                case 'c':
                    Console.WriteLine("input NO.{0} customer's purchase number", number + 1);
                    break;
                case 's':
                    Console.WriteLine("input purchase number by David Jones from NO.{0}'s supplier", number + 1);
                    break;
                default:
                    Console.WriteLine("parameter incorrect, c for customer and s for supplier");
                    break;
            }
            purchaseNum = Console.ReadLine();
            while (!double.TryParse(purchaseNum, out i) || double.Parse(purchaseNum) < 0.0)
            {
                Console.WriteLine("Invalid owing Number, should be double and greater or equal to 0, type again");
                PurchaseNum(number, cOrS);
            }
            return double.Parse(purchaseNum);
        }
        static double PaymentNum(int number, char cOrS)
        {
            double i;
            switch(cOrS)
            {
                case 'c':
                    Console.WriteLine("input NO.{0} customer's payment number", number + 1);
                    break;
                case 's':
                    Console.WriteLine("input NO.{0} supplier's payment number by David Jones", number + 1);
                    break;
                default:
                    Console.WriteLine("parameter incorrect, c for customer and s for supplier");
                    break;
            }
            paymentNum = Console.ReadLine();
            while (!double.TryParse(paymentNum, out i) || double.Parse(paymentNum) < 0.0)
            {
                Console.WriteLine("Invalid owing Number, should be double and greater or equal to 0, type again");
                PaymentNum(number, cOrS);
            }
            return double.Parse(paymentNum);
        }
    }
}
