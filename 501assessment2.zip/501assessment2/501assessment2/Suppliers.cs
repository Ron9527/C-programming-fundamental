﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _501assessment2
{
    class Suppliers
    {
        private string name = null;
        private int accountNum, month;
        private double owingNumBegin, purchasesNum, paymentsNum, owingNumEnd;
        public Suppliers()
        {

        }
        public string GetName
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public int GetAccountNum
        {
            get
            {
                return accountNum;
            }
            set
            {
                accountNum = value;
            }
        }
        public double GetOwingBegin
        {
            get
            {
                return owingNumBegin;
            }
            set
            {
                owingNumBegin = value;
            }
        }
        public double GetPurchasesNum
        {
            get
            {
                return purchasesNum;
            }
            set
            {
                purchasesNum = value;
            }
        }
        public double GetPayNum
        {
            get
            {
                return paymentsNum;
            }
            set
            {
                paymentsNum = value;
            }
        }
        public int GetMonth
        {
            get
            {
                return month;
            }
            set
            {
                month = value;
            }
        }
        public double GetOwingEnd(double owingBegin, double purchase, double payment)
        {
            owingNumEnd = owingBegin + purchase - payment;
            if (owingNumEnd > 500)
            {
                Console.WriteLine("Payment of this account is due now!!!!!!");
            }
            return owingNumEnd;
        }
        public override string ToString()
        {
            return $"supplier's name:\n{name}\nAccount Number:\n{accountNum}\nMonth:\n{month}\nOwing by David Jones at beginning:\n{owingNumBegin:c}\nTotal purchases number by David Jones:\n{purchasesNum:c}\nTotal payment number by David Jones:\n{paymentsNum:c}\nOwing by David Jones at end:\n{GetOwingEnd(owingNumBegin, purchasesNum, paymentsNum):c} ";
        }
    }
}
